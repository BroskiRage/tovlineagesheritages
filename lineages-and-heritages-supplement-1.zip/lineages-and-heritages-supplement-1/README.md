# Lineages & Heritages
## Introduction

A simple module that adds the lineages from the Lineage & Heritages supplement. 

## [documentation](https://koboldpress.com/kpstore/product/lineages-heritages-supplement-1/)

## Foundry Compatibility
This module has been tested to work with Foundry V13.<br>

## Credits
**Author**: Kelly Pawlik (Kobold Press)